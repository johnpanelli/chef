#
# Cookbook:: apache
# Recipe:: remove
#
# Copyright:: 2018, The Authors, All Rights Reserved.

package 'httpd' do
  action :remove
end
