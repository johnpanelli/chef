#
# Cookbook:: mysql
# Recipe:: server
#
# Copyright:: 2018, The Authors, All Rights Reserved.

package 'mysql-server'

service 'mysqld' do
  action [:enable, :start]
end

