#
# Cookbook:: mysql
# Recipe:: remove
#
# Copyright:: 2018, The Authors, All Rights Reserved.

package 'mysql-server' do
  action :remove
end

