package 'cowsay' do
  action :remove
end

package 'tree' do
  action :remove
end

package 'git' do
  action :remove
end
