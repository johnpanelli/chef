#
# Cookbook:: workstation
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.

include_recipe '::setup'

