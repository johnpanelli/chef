file 'hello.txt' do
  content 'Hello chef @ Intuit!'
  mode '0777'
  owner 'vagrant'
  group 'vagrant'
end
