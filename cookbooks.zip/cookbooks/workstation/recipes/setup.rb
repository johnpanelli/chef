#package 'cowsay' do
#  action :install
#end

package 'tree'

package 'git'

file '/etc/motd' do
  content 'Property of .....'
end
